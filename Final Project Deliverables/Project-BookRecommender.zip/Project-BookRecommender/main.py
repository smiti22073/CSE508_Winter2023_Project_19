from flask import Flask, render_template, request, redirect, url_for

import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
import librosa
from librosa import feature

import nltk
from nltk.corpus import stopwords 
nltk.download('stopwords')
nltk.download('words')
nltk.download('punkt')
from nltk.tokenize import word_tokenize
import re

def updateDescription(s):     #used in book_preprocessing()
    s = re.sub("\'", "", s)       
    s = re.sub("[^a-zA-Z]"," ",s)
    s = ' '.join(s.split())
    s = s.lower()   
    return s    

def preprocess_SW(desc):
    setSW = set(stopwords.words('english'))         
    tokens = word_tokenize(desc)
    newDesc = [x for x in tokens if not x.lower() in setSW]
    return ' '.join(newDesc)                       

def preprocess_genres(i):
    t = stopwords.words("english")
    pattern = re.compile(r'\b(' + r'|'.join(t) + r')\b\s*')
    tokens = nltk.word_tokenize(i)
    s = ""
    s = ", ".join(tokens)
    stopword_removed =[]    
    for word in tokens:
      word = pattern.sub('', word)
      if(len(word)> 0):
        stopword_removed.append(word)
    final_genre = ''  
    for word in stopword_removed:
      final_genre += (word+' ')  
    final_genre = final_genre.strip()  
    return final_genre

def music_to_book_mapping():
    genre_df = pd.read_csv('static/genre.csv')
    dct = {}
    dct.update(genre_df['m-genre'])
    dct 
    return dct

def book_preprocessing():
    import csv
    l = []

    with open("static/booksummaries.txt", 'r', encoding="utf8") as file:
        r = csv.reader(file, dialect='excel-tab')
        for row in r:
            l.append(row)
    Id = []
    Name = []
    Description = []
    Genre = []

    for i in l:
        Id.append(i[0])
        Name.append(i[2])
        Genre.append(i[5])
        Description.append(i[6])

    df = pd.DataFrame({'id': Id, 'name': Name, 'description': Description, 'genre': Genre})
    df['id'] = df['id'].astype('int')
    df.drop(df[df['genre']==''].index, inplace=True)
    df[df['genre']=='']
    print(list(np.where(df['name']=='The Chinese Gold Murders')))
    df.iloc[7240]
    import json as jsc
    l=[]
    for i in df['genre']:
        l.append(list(jsc.loads(i).values()))
    df['u-genre'] = l
    setOfgenre = sum(l,[])
    setOfgenre = set(setOfgenre)

    df['u-description'] = df['description'].apply(lambda x: updateDescription(x))
    df=df.drop(['genre', 'description'], axis=1)
    df.rename(columns = {'u-genre':'genre'}, inplace = True)
    df.rename(columns = {'u-description':'description'}, inplace = True)


    preprocess_SW("old major the old boar on the manor farm calls the animals on the farm for a meeting where he compares the humbooks to parasites and teaches the animals a revolutionary song beasts of england when major dies two young pigs snowball and napoleon assume command and turn his dream into a philosophy")
    df['description w/o SW'] = df['description'].apply(lambda x: preprocess_SW(x))

    #Grouping similar genres
    book_genres = setOfgenre


    temp_genre = []
    for i in df['genre']:
      temp_genre2 = []
      for j in i:
        temp_genre2.append(preprocess_genres(j))
      temp_genre.append(temp_genre2)
    df['m-genre'] = temp_genre

    temp_genre = []
    for i in df['m-genre']:
      temp_genre2 = i
      for j in i:
        if (j ==  'Bangsian fantasy'):
          temp_genre2.remove('Bangsian fantasy')   #related to afterlife book
          temp_genre2.append('Afterlife fantasy')
        elif (j ==  'Biopunk'):
          temp_genre2.remove('Biopunk')
          temp_genre2.append('Biotechnology fiction')  #related to biotech fiction
        elif (j ==  'Edisonade'):
          temp_genre2.remove('Edisonade')  #related to great inventor, engineer
          temp_genre2.append('Inventor fiction')  
        elif (j == 'Elizabethan romance'):
          temp_genre2.remove('Elizabethan romance')
        elif (j == 'Ergodic literature'):
          temp_genre2.remove('Ergodic literature')
        elif (j == 'Humour'):
          temp_genre2.remove('Humour')     
          temp_genre2.append('Humor')
        elif (j == 'Künstlerroman'):
          temp_genre2.remove('Künstlerroman') 
        elif (j == 'Postcyberpunk'):
          temp_genre2.remove('Postcyberpunk')     
          temp_genre2.append('cyberpunk')  
        elif (j == 'Robinsonade'):
          temp_genre2.remove('Robinsonade')
      temp_genre.append(temp_genre2)
    df['m-genre'] = temp_genre

    setOfgenre = sum(df['m-genre'],[])
    setOfgenre = set(setOfgenre)
    bk = list(setOfgenre)
    genre_vectors = []

    #main_genres = ['Fiction','Comedy','Adventure', 'Non-fiction', 'Romance', 'Mystery', 'Science Fiction', 'Fantasy', 'Horror', 'Historical Fiction', 'Young Adult', 'Spirituality']
    main_genres = ['History', 'Poetry', 'Autobiography', 'Romance','Biography', 'Literary', 'Spirituality', 'Western fiction', 'Comedy', 'Adventure',
                   'Dark', 'Sociology', 'Comic', 'Anthology', 'Drama', 'Thriller', 'Action',  'Conspiracy', 'Catastrophic', 
                   'Young adult','Fantasy', 'Travel', 'Science', 'Speculative', 'Horror', 'Mystery', 'Non fiction']

    book_genre_df = pd.read_csv('static/book_genre.csv')

    temp_genre = []
    for i in df['m-genre']:
      temp_genre2 = []
      for j in i:
        mapped_genre = book_genre_df[book_genre_df['genre']==j]['m-genre'].values[0]
        temp_genre2.append(mapped_genre)
      temp_genre.append(temp_genre2)
    df['m-genre'] = temp_genre
    return df

def gettop5books(y_pred, dct, df):
    import random
    result = []
    #print('hi')
    for i in range(len(y_pred)):
      label = y_pred[i]
      j = dct[label]
      str = j[2:-2]
      gen = list(str.split(', '))
      final_gen = []
      for g in gen:
         final_gen.append(g[1:-1])
      #print(final_gen)      #all genres for y_pred[i]
      for m in range(len(final_gen)):
        genre_name = final_gen[m]
        print("\n")
        print(final_gen[m])
        books = []
        for k in range(len(df)):
          if final_gen[m] in df['m-genre'].iloc[k]:
             books.append(df['name'].iloc[k])
        l3 = []
        if (len(books) > 5):
          l3 = (random.sample(books, 5))

        for book in l3:
           tup_list = []
           tup_list.append(final_gen[m])
           tup_list.append(book)
           result.append(tuple(tup_list))
    return result

app = Flask(__name__)

def hindi_music_to_book_train():
    Bolly_rap = pd.read_csv("static/Bollywood_Rap_features.csv")
    Bolly_rap['labels'] = pd.Series([0 for x in range(len(Bolly_rap.index))], index=Bolly_rap.index)

    Ghazal = pd.read_csv("static/Ghazal_features.csv")
    Ghazal['labels'] = pd.Series([1 for x in range(len(Ghazal.index))], index=Ghazal.index)

    Garhwali = pd.read_csv("static/Garhwali_features.csv")
    Garhwali['labels'] = pd.Series([2 for x in range(len(Garhwali.index))], index=Garhwali.index)

    bhajan = pd.read_csv("static/bhajan_features.csv")
    bhajan['labels'] = pd.Series([3 for x in range(len(bhajan.index))], index=bhajan.index)

    bolly_romantic = pd.read_csv("static/Bollywood_Romantic_features.csv")
    bolly_romantic['labels'] = pd.Series([4 for x in range(len(bolly_romantic.index))], index=bolly_romantic.index)

    sufi = pd.read_csv("static/sufi_features.csv")
    sufi['labels'] = pd.Series([5 for x in range(len(sufi.index))], index=sufi.index)

    bhojpuri = pd.read_csv("static/bhojpuri_features.csv")
    bhojpuri['labels'] = pd.Series([6 for x in range(len(bhojpuri.index))], index=bhojpuri.index)

    frame = pd.concat([Bolly_rap, Ghazal, Garhwali, bhajan, bolly_romantic, sufi, bhojpuri], ignore_index=True)
    final = frame.drop("Unnamed: 0", axis=1)
    final.to_csv("all_features.csv")
    X = final.drop(["labels", "Song_Name"], axis=1)
    y = final["labels"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    import lightgbm as lgb
    clf = lgb.LGBMClassifier(boosting_type='gbdt', learning_rate=0.2, min_child_samples=20)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    print(y_pred)
    print(y_test)

    from sklearn.metrics import accuracy_score
    accuracy = accuracy_score(y_pred, y_test)
    print('LightGBM Model accuracy score: {0:0.4f}'.format(accuracy_score(y_test, y_pred)))
    return clf

def english_music_to_book_train():
    blues = pd.read_csv("static/static_english/blues_features.csv")
    blues['labels'] = pd.Series([0 for x in range(len(blues.index))], index=blues.index)

    classical = pd.read_csv("static/static_english/classical_features.csv")
    classical['labels'] = pd.Series([1 for x in range(len(classical.index))], index=classical.index)

    country = pd.read_csv("static/static_english/country_features.csv")
    country['labels'] = pd.Series([2 for x in range(len(country.index))], index=country.index)

    disco = pd.read_csv("static/static_english/disco_features.csv")
    disco['labels'] = pd.Series([3 for x in range(len(disco.index))], index=disco.index)

    hiphop = pd.read_csv("static/static_english/hiphop_features.csv")
    hiphop['labels'] = pd.Series([4 for x in range(len(hiphop.index))], index=hiphop.index)

    jazz = pd.read_csv("static/static_english/jazz_features.csv")
    jazz['labels'] = pd.Series([5 for x in range(len(jazz.index))], index=jazz.index)

    metal = pd.read_csv("static/static_english/metal_features.csv")
    metal['labels'] = pd.Series([6 for x in range(len(metal.index))], index=metal.index)

    pop = pd.read_csv("static/static_english/pop_features.csv")
    pop['labels'] = pd.Series([7 for x in range(len(pop.index))], index=pop.index)

    raggae = pd.read_csv("static/static_english/reggae_features.csv")
    raggae['labels'] = pd.Series([8 for x in range(len(raggae.index))], index=raggae.index)

    rock = pd.read_csv("static/static_english/rock_features.csv")
    rock['labels'] = pd.Series([9 for x in range(len(rock.index))], index=rock.index)

    frame = pd.concat([blues, classical, country, disco, hiphop, jazz, metal, pop, raggae, rock], ignore_index=True)
    frame.head()

    final = frame.drop("Unnamed: 0", axis=1)
    final.to_csv("all_features.csv")

    final.head()

    from sklearn.metrics import confusion_matrix
    from sklearn.model_selection import train_test_split
    from sklearn.model_selection import cross_val_score
    from sklearn import preprocessing

    # X = preprocessing.scale(final.drop(["labels", "Song_Name"], axis=1))
    # y = final["labels"]
    X = final.drop(["labels", "Song_Name"], axis=1)
    y = final["labels"]

    final.shape

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    X_test


    import lightgbm as lgb
    clf = lgb.LGBMClassifier(boosting_type='gbdt', learning_rate=0.2, min_child_samples=20)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)

    from sklearn.metrics import accuracy_score, classification_report
    accuracy = accuracy_score(y_pred, y_test)
    print('LightGBM Model accuracy score: {0:0.4f}'.format(accuracy_score(y_test, y_pred)))

    return clf

@app.route('/decider')
def decider():
   return render_template('decider.html')

@app.route('/assistant1')
def assistant1():
    return render_template('assistant1.html')


@app.route('/assistant1', methods=['GET', 'POST'])
def hindi_music_to_book_test():
    if request.method == 'POST':
        f = request.files['file']
        print(f.filename)
        f.save(f.filename)
        fn_list_i = [
            librosa.onset.onset_strength,
            feature.chroma_stft,
            feature.chroma_cqt,
            feature.chroma_cens,
            feature.melspectrogram,
            feature.mfcc,
            feature.spectral_centroid,
            feature.spectral_bandwidth,
            feature.spectral_contrast,
            feature.spectral_rolloff,
            feature.tonnetz
        ]
        fn_list_ii = [
            feature.zero_crossing_rate
        ]
                        # from glob import glob
        test_files = []
        test_files.append(f.filename)
        columns = ["Song_Name", "onset_strength", "chroma_stft", "chroma_cqt", "chroma_cens", "melspectrogram", "mfcc",
                   "spectral_centroid", "spectral_bandwidth", "spectral_contrast", "spectral_rolloff", "tonnetz",
                   "zero_crossing_rate"]
        song_features = []
        for file in test_files:
            '''
            y is the time series array of the audio file, a 1D np.ndarray
            sr is the sampling rate, a number
            '''
            y, sr = librosa.load(librosa.util.example_audio_file())
            feat_vect_i = [np.mean(funct(y, sr)) for funct in fn_list_i]
            feat_vect_ii = [np.mean(funct(y)) for funct in fn_list_ii]
            feature_vector = feat_vect_i + feat_vect_ii
            song_features.append([file] + feature_vector)
        df = pd.DataFrame(song_features, columns=columns)
        print(df)
        file_name = 'test_file_features.csv'
        df.to_csv(file_name)
        test = pd.read_csv("./test_file_features.csv")
        test.head()
        X_test = test.drop(['Unnamed: 0', 'Song_Name'], axis=1)
        X_test.head()
        clf = hindi_music_to_book_train()
        y_pred = clf.predict(X_test)
        for i in range(len(test_files)):
            print(test_files[i], " : ", y_pred[i])
        dct = music_to_book_mapping()
        #print(dct)
        df1 = book_preprocessing()
        #print(df1)
        result = gettop5books(y_pred, dct, df1)
        print("Result", result)
    #t = (('genre1','book1'), ('genre1','book1'))
    #replacing with result, which is list of tuples
    x = tuple(result)
    from tabulate import tabulate
    x = tabulate(x)
    x = x.replace("-", "")
    x = x.lstrip(" ")
    x = x.rstrip(" ")
    print(x)
    x = x.replace('\n', '<br>')
    return redirect(url_for('output', d = x))


@app.route('/')
def first():
    return render_template('Home.html')

headings = ("Book genre", "Book name")

@app.route('/output/<d>')
def output(d):
    return render_template('output.html', headings = headings, data = d)

@app.route('/b2b')
def b2b():
    return render_template('b2b.html')

@app.route('/b2b', methods=['GET', 'POST'])
def b2b_test():
    if request.method == 'POST':
        inp = request.values['book-desc']
        print(inp)
        import numpy as np
        import pandas as pd
        from sklearn.model_selection import train_test_split
        import json as jsc
        import re
        import nltk
        from nltk.corpus import stopwords
        from nltk.tokenize import word_tokenize
        from sklearn.preprocessing import MultiLabelBinarizer
        from sklearn.model_selection import train_test_split
        from sklearn.linear_model import LogisticRegression
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.multiclass import OneVsRestClassifier
        from sklearn.metrics import f1_score, accuracy_score
        
        import csv
        nltk.download('stopwords')
        nltk.download('words')
        nltk.download('punkt')


        Id = []
        Name = []
        Description = []
        Genre = []

        l = []

        with open("static/booksummaries.txt", 'r', encoding="utf8") as file:
            r = csv.reader(file, dialect='excel-tab')
            for row in r:
                l.append(row)

        for i in l:
            Id.append(i[0])
            Name.append(i[2])
            Genre.append(i[5])
            Description.append(i[6])

        df = pd.DataFrame({'id': Id, 'name': Name, 'description': Description,
                           'genre': Genre})

        df['id'] = df['id'].astype('int')

        df.drop(df[df['genre'] == ''].index, inplace=True)
        df[df['genre'] == '']


        jsc.loads(df['genre'][0]).values()

        l = []
        for i in df['genre']:
            l.append(list(jsc.loads(i).values()))

        df['u-genre'] = l

        setOfgenre = sum(l, [])
        setOfgenre = set(setOfgenre)

        def updateDescription(s):
            s = re.sub("\'", "", s)
            s = re.sub("[^a-zA-Z]", " ", s)
            s = ' '.join(s.split())
            s = s.lower()
            return s

        df['u-description'] = df['description'].apply(lambda x: updateDescription(x))
        df = df.drop(['genre', 'description'], axis=1)
        df.rename(columns={'u-genre': 'genre'}, inplace=True)
        df.rename(columns={'u-description': 'description'}, inplace=True)



        def preprocess_SW(desc):
            setSW = set(stopwords.words('english'))
            tokens = word_tokenize(desc)
            newDesc = [x for x in tokens if not x.lower() in setSW]
            return ' '.join(newDesc)


        df['description w/o SW'] = df['description'].apply(lambda x: preprocess_SW(x))

        book_genres = setOfgenre


        def preprocess_genres(i):
            t = stopwords.words("english")
            pattern = re.compile(r'\b(' + r'|'.join(t) + r')\b\s*')
            tokens = nltk.word_tokenize(i)
            s = ""
            s = ", ".join(tokens)
            stopword_removed = []
            for word in tokens:
                word = pattern.sub('', word)
                if (len(word) > 0):
                    stopword_removed.append(word)
            final_genre = ''
            for word in stopword_removed:
                final_genre += (word + ' ')
            final_genre = final_genre.strip()
            return final_genre

        temp_genre = []
        for i in df['genre']:
            temp_genre2 = []
            for j in i:
                temp_genre2.append(preprocess_genres(j))
            temp_genre.append(temp_genre2)
        df['m-genre'] = temp_genre

        temp_genre = []
        for i in df['m-genre']:
            temp_genre2 = i
            for j in i:
                if (j == 'Bangsian fantasy'):
                    temp_genre2.remove('Bangsian fantasy')  # related to afterlife book
                    temp_genre2.append('Afterlife fantasy')
                elif (j == 'Biopunk'):
                    temp_genre2.remove('Biopunk')
                    temp_genre2.append('Biotechnology fiction')  # related to biotech fiction
                elif (j == 'Edisonade'):
                    temp_genre2.remove('Edisonade')  # related to great inventor, engineer
                    temp_genre2.append('Inventor fiction')
                elif (j == 'Elizabethan romance'):
                    temp_genre2.remove('Elizabethan romance')
                elif (j == 'Ergodic literature'):
                    temp_genre2.remove('Ergodic literature')
                elif (j == 'Humour'):
                    temp_genre2.remove('Humour')
                    temp_genre2.append('Humor')
                elif (j == 'Künstlerroman'):
                    temp_genre2.remove('Künstlerroman')
                elif (j == 'Postcyberpunk'):
                    temp_genre2.remove('Postcyberpunk')
                    temp_genre2.append('cyberpunk')
                elif (j == 'Robinsonade'):
                    temp_genre2.remove('Robinsonade')
            temp_genre.append(temp_genre2)
        df['m-genre'] = temp_genre


        book_genre_df = pd.read_csv("static/book_genre.csv")

        temp_genre = []
        for i in df['m-genre']:
            temp_genre2 = []
            for j in i:
                mapped_genre = book_genre_df[book_genre_df['genre'] == j]['m-genre'].values[0]
                temp_genre2.append(mapped_genre)
            temp_genre.append(temp_genre2)
        df['m-genre'] = temp_genre

        mBin = MultiLabelBinarizer()
        mBin.fit(df['m-genre'])
        label = mBin.transform(df['m-genre'])

        ##Splitting into training and testing data
        trainData, testData, trainLabel, testLabel = train_test_split(df['description w/o SW'], label, random_state=0,
                                                                      train_size=.80)

        ##Converting the input text to feature vectors
        tfidf_vectorizer = TfidfVectorizer(max_df=0.8, max_features=10000)
        trainData_v = tfidf_vectorizer.fit_transform(trainData)
        testData_v = tfidf_vectorizer.transform(testData)

        lr = LogisticRegression()
        clf = OneVsRestClassifier(lr)
        clf.fit(trainData_v, trainLabel)

        y_pred = clf.predict(testData_v)
        f1_score(testLabel, y_pred, average="micro"), accuracy_score(testLabel, y_pred)

        def predict(m):
            m = updateDescription(m)
            m = preprocess_SW(m)
            m_vec = tfidf_vectorizer.transform([m])
            m_pred = clf.predict(m_vec)
            return mBin.inverse_transform(m_pred)

        final_list = []

        import random
        s = predict(inp)
        for i in s:
            # print(i)
            l2 = list(i)

        for i in l2:
            # j = set(i)
            ln = []
            for m in range(len(df['m-genre'])):
                if (i in df['m-genre'].iloc[m]):
                    ln.append(m)
            if (len(ln) > 5):
                l3 = (random.sample(ln, 5))
                print(l3)
            for i in l3:
                # print(i)
                lgnd = []
                # print(df['name'].iloc[i])
                # print(df['description'].iloc[i])
                # print(df['m-genre'].iloc[i])
                lgnd.append(df['m-genre'].iloc[i])
                lgnd.append(df['name'].iloc[i])
                # lgnd.append(df['description'].iloc[i])
                # lgnd.append(df['m-genre'].iloc[i])
                # print(lgnd)
                final_list.append(tuple(lgnd))

        x = tuple(final_list)
        from tabulate import tabulate
        x = tabulate(x)
        x = x.replace("-", "")
        x = x.lstrip(" ")
        x = x.rstrip(" ")
        print(x)
        x = x.replace('\n', '<br>')
        return redirect(url_for('output', d = x))

def english_music_to_book_mapping():
    genre_df = pd.read_csv('static/eng_genre.csv')
    dct = {}
    dct.update(genre_df['m-genre'])
    dct
    return dct

@app.route('/assistant2')
def assistant2():
    return render_template('assistant2.html')


@app.route('/assistant2', methods=['GET', 'POST'])
def english_music_to_book_test():
    if request.method == 'POST':
        f = request.files['file']
        print(f.filename)
        f.save(f.filename)
        fn_list_i = [
            librosa.onset.onset_strength,
            feature.chroma_stft,
            feature.chroma_cqt,
            feature.chroma_cens,
            feature.melspectrogram,
            feature.mfcc,
            feature.spectral_centroid,
            feature.spectral_bandwidth,
            feature.spectral_contrast,
            feature.spectral_rolloff,
            feature.tonnetz
        ]
        fn_list_ii = [
            feature.zero_crossing_rate
        ]
        # from glob import glob
        test_files = []
        test_files.append(f.filename)
        columns = ["Song_Name", "onset_strength", "chroma_stft", "chroma_cqt", "chroma_cens", "melspectrogram", "mfcc",
                   "spectral_centroid", "spectral_bandwidth", "spectral_contrast", "spectral_rolloff", "tonnetz",
                   "zero_crossing_rate"]
        song_features = []
        for file in test_files:
            '''
            y is the time series array of the audio file, a 1D np.ndarray
            sr is the sampling rate, a number
            '''
            y, sr = librosa.load(librosa.util.example_audio_file())
            feat_vect_i = [np.mean(funct(y, sr)) for funct in fn_list_i]
            feat_vect_ii = [np.mean(funct(y)) for funct in fn_list_ii]
            feature_vector = feat_vect_i + feat_vect_ii
            song_features.append([file] + feature_vector)
        df = pd.DataFrame(song_features, columns=columns)
        print(df)
        file_name = 'test_file_features.csv'
        df.to_csv(file_name)
        test = pd.read_csv("./test_file_features.csv")
        test.head()
        X_test = test.drop(['Unnamed: 0', 'Song_Name'], axis=1)
        X_test.head()
        clf = english_music_to_book_train()
        y_pred = clf.predict(X_test)
        for i in range(len(test_files)):
            print(test_files[i], " : ", y_pred[i])
        dct = english_music_to_book_mapping()
        # print(dct)
        df1 = book_preprocessing()
        # print(df1)
        result = gettop5books(y_pred, dct, df1)
        # print(result)
    # t = (('genre1','book1'), ('genre1','book1'))
    # replacing with result, which is list of tuples
    from tabulate import tabulate
    x = tabulate(result)
    x = x.replace("-", "")
    x = x.lstrip(" ")
    x = x.rstrip(" ")
    print(x)
    x = x.replace('\n', '<br>')
    return redirect(url_for('output', d=x))




def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    app.run(debug=True)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
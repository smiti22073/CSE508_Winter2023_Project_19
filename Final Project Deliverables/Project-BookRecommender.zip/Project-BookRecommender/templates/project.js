function getValue(){
var name = document.getElementById('Company').value;

var gstn = document.getElementById('gst').value;

var idea = document.getElementById('pitch').value;

var bmodel = document.getElementById('model').value;

var revenue = document.getElementById('rev').value;

var gross = document.getElementById('gSale').value;

var prof = document.getElementById('nprof').value;
alert("Hello");
document.getElementById('disp').innerText = name;

}

function LoopTest() {
var i=0;
var stop=5;
for (i=0;i<5;i++) {  
 var v = document.createElement('p');
 // v.type="button";
 // v.value="Button " +i;
 v.innerText = "Book : "+i;
 document.getElementById('test').appendChild(v);
}
}


